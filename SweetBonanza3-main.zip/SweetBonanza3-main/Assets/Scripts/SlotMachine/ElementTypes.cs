namespace Bonanza
{
    public enum ElementTypes
    {
        blue,
        red,
        green,
        yellow,
        purple,
        orange,
        white,
        black
    }
}